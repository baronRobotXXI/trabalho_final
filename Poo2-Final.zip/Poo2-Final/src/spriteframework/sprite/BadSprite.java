package spriteframework.sprite;

import java.util.LinkedList;

public abstract class BadSprite extends Sprite {
	private int directionChangeDelay = 0;
	private int spriteIndex;
	private boolean frozen = false;
	// Declaração das flags para controlar a direção do movimento
	private boolean movingLeft;
	private boolean movingRight;
	private boolean movingUp;
	private boolean movingDown;

	public boolean isFrozen() {
		return frozen;
	}

	public void setFrozen(boolean frozen) {
		this.frozen = frozen;
	}

	public int getSpriteIndex() {
		return spriteIndex;
	}

	// Getters e setters para as flags de movimento
	public boolean isMovingLeft() {
		return movingLeft;
	}

	public void setMovingLeft(boolean movingLeft) {
		this.movingLeft = movingLeft;
	}

	public boolean isMovingRight() {
		return movingRight;
	}

	public void setMovingRight(boolean movingRight) {
		this.movingRight = movingRight;
	}

	public boolean isMovingUp() {
		return movingUp;
	}

	public void setMovingUp(boolean movingUp) {
		this.movingUp = movingUp;
	}

	public boolean isMovingDown() {
		return movingDown;
	}

	public void setMovingDown(boolean movingDown) {
		this.movingDown = movingDown;
	}

	public LinkedList<BadSprite> getBadnesses() {
		return null;
	}

	public boolean isDestroyed() {
		return false;
	}

	public void act() {
		//
	}

	public void setDirectionChangeDelay(int delay) {
		directionChangeDelay = delay;
	}

	public int getDirectionChangeDelay() {
		return directionChangeDelay;
	}

	public void decrementDirectionChangeDelay() {
		if (directionChangeDelay > 0) {
			directionChangeDelay--;
		}
	}
}
