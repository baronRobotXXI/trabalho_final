package spriteframework.sprite;

import javax.swing.*;

import spriteframework.Commons;
import spriteframework.image.CowboyPlayerFactory;
import spriteframework.image.PlayerFactory;
import spriteframework.strategy.MovementStrategy;

import java.awt.Image;
import java.awt.event.KeyEvent;

public class Player extends Sprite {
    private MovementStrategy movementStrategy;
    private int width;
    private int boardWidth;
    private int boardHeight;
    private int height;
    private int lastDirectionX; // true para direita, false para esquerda
    private int lastDirectionY; // true para baixo, false para cima
    private PlayerFactory playerFactory;
    private Timer timer;
    private Player player;

    public void setBoard(int boardWidth, int boardHeight) {
        this.boardWidth = boardWidth;
        this.boardHeight = boardHeight;
    }

    public Player() {
        resetState();
    }

    public void setPlayerFactory(PlayerFactory factory) {
        this.playerFactory = factory;
        loadImage();
    }

    public void setImage(PlayerFactory player) {
        this.playerFactory = player;
        loadImage();
        getImageDimensions();
    }

    public void loadImage() {
        image = playerFactory.createImage();
        setImage(image);
    }

    public int getLastDirectionX() {
        return lastDirectionX;
    }

    public void setLastDirectionX(int lastDirectionX) {
        this.lastDirectionX = lastDirectionX;
    }

    public int getLastDirectionY() {
        return lastDirectionY;
    }

    public void setLastDirectionY(int lastDirectionY) {
        this.lastDirectionY = lastDirectionY;
    }

    public void setMovementStrategy(MovementStrategy strategy) {
        this.movementStrategy = strategy;
    }


    public void act() {
        x += dx;
        y += dy;

        if (x <= 2) {
            x = 2;
        }
        if (x >= boardWidth - 2 * width) {
            x = boardWidth - 2 * width;
        }
        if(playerFactory instanceof CowboyPlayerFactory){
             if (y <= 2) {
                 y = 2;
                }
            if (y >= boardHeight - 2 * height) { // Defina `boardHeight` conforme necessário
                y = boardHeight - 2 * height;
                }
        }
    }

    public void keyPressed(KeyEvent e) {
        int key = e.getKeyCode();
        int moveSpeed = 3;
        if (key == KeyEvent.VK_LEFT || key == KeyEvent.VK_RIGHT || key == KeyEvent.VK_UP || key == KeyEvent.VK_DOWN) {
            if (movementStrategy != null) {
                if (key == KeyEvent.VK_LEFT) {
                    dx = -moveSpeed;
                } else if (key == KeyEvent.VK_RIGHT) {
                    dx = moveSpeed;
                } else if (key == KeyEvent.VK_UP && playerFactory instanceof CowboyPlayerFactory) {
                    dy = -moveSpeed;
                } else if (key == KeyEvent.VK_DOWN && playerFactory instanceof CowboyPlayerFactory) {
                    dy = moveSpeed;
                }
            }
        }
    }

    public void keyReleased(KeyEvent e) {

        int key = e.getKeyCode();
        if (key == KeyEvent.VK_LEFT || key == KeyEvent.VK_RIGHT) {
            dx = 0;
        }
        if (key == KeyEvent.VK_UP || key == KeyEvent.VK_DOWN) {
            dy = 0;
        }
    }

    private void resetState() {

        setX(Commons.INIT_PLAYER_X);
        setY(Commons.INIT_PLAYER_Y);
    }
}
