package spriteframework.strategy;

import spriteframework.sprite.Player;

public interface MovementStrategy {
    void moveLeft(Player player);

    void moveRight(Player player);

    void moveUp(Player player);

    void moveDown(Player player);
}
