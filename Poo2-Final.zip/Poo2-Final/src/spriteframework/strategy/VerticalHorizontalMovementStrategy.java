package spriteframework.strategy;

import spriteframework.sprite.Player;

public class VerticalHorizontalMovementStrategy implements MovementStrategy {
    @Override
    public void moveLeft(Player player) {
        player.setX(player.getX() - 2);

    }

    @Override
    public void moveRight(Player player) {
        player.setX(player.getX() + 2);

    }

    @Override
    public void moveUp(Player player) {
        player.setY(player.getY() - 2);

    }

    @Override
    public void moveDown(Player player) {
        player.setY(player.getY() + 2);

    }
}
