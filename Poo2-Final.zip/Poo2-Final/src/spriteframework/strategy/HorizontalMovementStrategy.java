package spriteframework.strategy;

import spriteframework.sprite.Player;

public class HorizontalMovementStrategy implements MovementStrategy {
    @Override
    public void moveLeft(Player player) {
        player.setX(player.getX() - 2);
    }

    @Override
    public void moveRight(Player player) {
        player.setX(player.getX() + 2);
    }

    @Override
    public void moveUp(Player player) {
        // Não faz nada, já que o movimento vertical não é permitido
    }

    @Override
    public void moveDown(Player player) {
        // Não faz nada, já que o movimento vertical não é permitido
    }
}
