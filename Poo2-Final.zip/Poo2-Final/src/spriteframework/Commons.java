package spriteframework;

public interface Commons {

    int BORDER_RIGHT = 10;
    int BORDER_LEFT = 5;
    int INIT_PLAYER_X = 21;
    int INIT_PLAYER_Y = 280;
    int DELAY = 30;
}
