package spriteframework.image;

import javax.swing.ImageIcon;
import java.awt.*;

public interface PlayerFactory {
    Image createImage();
}