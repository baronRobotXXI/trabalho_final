package spriteframework.image;

import javax.swing.ImageIcon;
import java.awt.*;

public class CowboyPlayerFactory implements PlayerFactory {

    @Override
    public Image createImage() {
        ImageIcon ii = new ImageIcon("images/woody.png");
        Image image = ii.getImage().getScaledInstance(30, 40, Image.SCALE_DEFAULT);

        return image;
    }
}
