package spriteframework;

import javax.swing.JFrame;

public abstract class MainFrame extends JFrame {

	protected abstract AbstractBoard createBoard(int boardWidth, int boardHeight, int ground);

	public MainFrame(String title, int boardWidth, int boardHeight, int ground) {
		setTitle(title);
		setSize(boardWidth, boardHeight);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setResizable(false);
		setLocationRelativeTo(null);
		add(createBoard(boardWidth, boardHeight, ground));
		setVisible(true);
	}
}

// public static void main(String[] args) {
//
// EventQueue.invokeLater(() -> {
//
// MainFrameExtended ex = new MainFrameExtended();
// });
// }
