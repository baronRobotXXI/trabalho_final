package freezemonsters.sprite;

import java.awt.Image;

import javax.swing.ImageIcon;

import spriteframework.sprite.BadSprite;

public class Shot extends BadSprite {

    private int directionX; // Direção horizontal do movimento (esquerda: -1, direita: 1)
    private int directionY; // Direção vertical do movimento (cima: -1, baixo: 1)

    public Shot(int x, int y, int directionX, int directionY) {
        initShot(x, y, directionX, directionY);

    }

    private void initShot(int x, int y, int directionX, int directionY) {
        String shotImg = "images/ray.png";
        ImageIcon ii = new ImageIcon(shotImg);
        Image image = ii.getImage().getScaledInstance(15, 15, Image.SCALE_DEFAULT);
        setImage(image);

        int H_SPACE = 6;
        setX(x + H_SPACE);

        int V_SPACE = 6;
        setY(y - V_SPACE);

        // Definindo a direção do tiro
        this.directionX = directionX;
        this.directionY = directionY;
    }

    public int getDirectionX() {
        return directionX;
    }

    public int getDirectionY() {
        return directionY;
    }
}
