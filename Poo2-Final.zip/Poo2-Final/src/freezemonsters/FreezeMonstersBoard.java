package freezemonsters;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.KeyEvent;
import java.util.Iterator;
import java.util.Random;

import javax.swing.ImageIcon;

import freezemonsters.sprite.MonsterSprite;
import spriteframework.AbstractBoard;
import spriteframework.sprite.BadSprite;
import spriteframework.sprite.Player;

import freezemonsters.sprite.*;

public class FreezeMonstersBoard extends AbstractBoard {
    public FreezeMonstersBoard(int boardWidth, int boardHeight, int ground) {
        super(boardWidth, boardHeight, ground);

    }

    // define sprites
    // private List<BadSprite> aliens;
    private Shot shot;

    // def ine global control vars
    private int direction = -1;
    private int deaths = 0;

    private String explImg = "images/explosion.png";

    protected void createBadSprites() { // create sprites
        for (int i = 1; i < 10; i++) {
            String monster = "images/monster" + i + ".png";
            MonsterSprite alien = new MonsterSprite(Commons.ALIEN_INIT_X + 18 * i,
                    Commons.ALIEN_INIT_Y + 18 * i, monster, i);
            badSprites.add(alien);

        }
    }

    protected void createOtherSprites() {
        shot = new Shot(0, 0, 0, 0);

        for (BadSprite alien : badSprites) {
            Goop goop = new Goop(alien.getX(), alien.getY());
            ((MonsterSprite) alien).setGoop(goop);
        }
    }

    private void drawShot(Graphics g) {

        if (shot.isVisible()) {

            g.drawImage(shot.getImage(), shot.getX(), shot.getY(), this);
        }
    }

    // Override
    protected void drawOtherSprites(Graphics g) {
        drawShot(g);
    }

    protected void processOtherSprites(Player player, KeyEvent e) {
        int x = player.getX();
        int y = player.getY();

        int key = e.getKeyCode();

        // Determina a direção do tiro com base nas teclas pressionadas
        int directionX = 0;
        int directionY = 0;

        // Atualiza as variáveis de direção do último movimento se uma tecla de
        // movimento for pressionada
        if (key == KeyEvent.VK_LEFT) {
            player.setLastDirectionX(-1); // Mover para a esquerda
            player.setLastDirectionY(0);
        } else if (key == KeyEvent.VK_RIGHT) {
            player.setLastDirectionX(1); // Mover para a direita
            player.setLastDirectionY(0);
        } else if (key == KeyEvent.VK_UP) {
            player.setLastDirectionY(-1); // Mover para cima
            player.setLastDirectionX(0);
        } else if (key == KeyEvent.VK_DOWN) {
            player.setLastDirectionY(1); // Mover para baixo
            player.setLastDirectionX(0);
        }

        // Use as variáveis de direção do último movimento ao disparar o tiro
        if (key == KeyEvent.VK_SPACE) {
            if (inGame) {
                if (!shot.isVisible()) {
                    directionX = player.getLastDirectionX();
                    directionY = player.getLastDirectionY();
                    // Cria o tiro com a direção determinada
                    shot = new Shot(x, y, directionX, directionY);
                }
            }
        }
    }

    // private void gameOver(Graphics g) {
    //
    // g.setColor(Color.black);
    // g.fillRect(0, 0, Commons.BOARD_WIDTH, Commons.BOARD_HEIGHT);
    //
    // g.setColor(new Color(0, 32, 48));
    // g.fillRect(50, Commons.BOARD_WIDTH / 2 - 30, Commons.BOARD_WIDTH - 100, 50);
    // g.setColor(Color.white);
    // g.drawRect(50, Commons.BOARD_WIDTH / 2 - 30, Commons.BOARD_WIDTH - 100, 50);
    //
    // Font small = new Font("Helvetica", Font.BOLD, 14);
    // FontMetrics fontMetrics = this.getFontMetrics(small);
    //
    // g.setColor(Color.white);
    // g.setFont(small);
    // g.drawString(message, (Commons.BOARD_WIDTH -
    // fontMetrics.stringWidth(message)) / 2,
    // Commons.BOARD_WIDTH / 2);
    // }

    protected void update() {
        // 1. Verifica se o número de alienígenas destruídos é igual ao número total de
        // alienígenas a serem destruídos.
        if (deaths == Commons.NUMBER_OF_ALIENS_TO_DESTROY) {
            inGame = false; // Se sim, o jogo é considerado vencido.
            timer.stop();
            message = "Game won!";
        }

        // 2. Executa a função act() para cada jogador, que atualiza a posição do
        // jogador com base em sua lógica de movimento.
        for (Player player : players)
            player.act();

        // 3. Verifica se o tiro está visível.
        // Verifica se o tiro está visível.
        if (shot.isVisible()) {
            int shotX = shot.getX();
            int shotY = shot.getY();

            // Verifica se o tiro colide com algum alienígena.
            for (BadSprite alien : badSprites) {
                int alienX = alien.getX();
                int alienY = alien.getY();

                if (alien.isVisible() && shot.isVisible()) {
                    if (shotX >= (alienX) && shotX <= (alienX + Commons.ALIEN_WIDTH)
                            && shotY >= (alienY) && shotY <= (alienY + Commons.ALIEN_HEIGHT)) {
                        // Define a imagem do alienígena como congelada
                        Image frozenImage = ((MonsterSprite) alien).getImageFrozen(); // Obtém a imagem congelada do
                                                                                      // monstro
                        alien.setImage(frozenImage);
                        // Marca o alienígena como morrendo
                        alien.setFrozen(true);
                        System.out.println(deaths);
                        deaths++;
                        // Destrói o tiro
                        shot.die();
                    }
                }
            }

            // Move o tiro na direção determinada
            int speed = 9; // Ajuste conforme necessário

            if (shot.getDirectionX() != 0) {
                // Mover apenas na direção X

                int x = shot.getX() + speed * shot.getDirectionX();
                shot.setX(x);
            } else if (shot.getDirectionY() != 0) {
                // Mover apenas na direção Y

                int y = shot.getY() + speed * shot.getDirectionY();
                shot.setY(y);
            }

            // Verifica se o tiro saiu da tela
            if (shot.getX() < 0 || shot.getX() >= boardWidth || shot.getY() < 0 || shot.getY() >= ground) {
                shot.die();
            }
        }

        // 4. Atualiza a posição dos alienígenas.
        Random generator = new Random();

        for (BadSprite alien : badSprites) {
            if (!alien.isFrozen()) {

                int x = alien.getX();
                int y = alien.getY();

                // Verifica se é hora de mudar a direção
                if (alien.getDirectionChangeDelay() <= 0) {
                    // Define um novo atraso de mudança de direção aleatório
                    alien.setDirectionChangeDelay(generator.nextInt(200) + 150); // Atraso entre 120 e 359 frames

                    // Escolhe uma nova direção aleatória
                    int randomMovement = generator.nextInt(8); // Gera um número aleatório entre 0 e 7

                    // Define a velocidade de movimento

                    // Lógica de movimento aleatório
                    switch (randomMovement) {
                        case 0: // Move para a esquerda
                            alien.setMovingLeft(true);
                            alien.setMovingRight(false);
                            alien.setMovingUp(false);
                            alien.setMovingDown(false);
                            break;
                        case 1: // Move para a direita
                            alien.setMovingLeft(false);
                            alien.setMovingRight(true);
                            alien.setMovingUp(false);
                            alien.setMovingDown(false);
                            break;
                        case 2: // Move para cima
                            alien.setMovingLeft(false);
                            alien.setMovingRight(false);
                            alien.setMovingUp(true);
                            alien.setMovingDown(false);
                            break;
                        case 3: // Move para baixo
                            alien.setMovingLeft(false);
                            alien.setMovingRight(false);
                            alien.setMovingUp(false);
                            alien.setMovingDown(true);
                            break;
                        case 4: // Move na diagonal superior esquerda (cima e esquerda)
                            alien.setMovingLeft(true);
                            alien.setMovingRight(false);
                            alien.setMovingUp(true);
                            alien.setMovingDown(false);
                            break;
                        case 5: // Move na diagonal inferior direita (baixo e direita)
                            alien.setMovingLeft(false);
                            alien.setMovingRight(true);
                            alien.setMovingUp(false);
                            alien.setMovingDown(true);
                            break;
                        case 6: // Move na diagonal inferior esquerda (baixo e esquerda)
                            alien.setMovingLeft(true);
                            alien.setMovingRight(false);
                            alien.setMovingUp(false);
                            alien.setMovingDown(true);
                            break;
                        case 7: // Move na diagonal superior direita (cima e direita)
                            alien.setMovingLeft(false);
                            alien.setMovingRight(true);
                            alien.setMovingUp(true);
                            alien.setMovingDown(false);
                            break;
                        default:
                            break;
                    }
                }

                // Move o alienígena na direção atual
                int speed = 1; // Ajuste conforme necessário
                if (alien.isMovingLeft()) {
                    alien.moveX(-speed);
                } else if (alien.isMovingRight()) {
                    alien.moveX(speed);
                }
                if (alien.isMovingUp()) {
                    alien.moveY(-speed);
                } else if (alien.isMovingDown()) {
                    alien.moveY(speed);
                }

                // Verifica se o alienígena atingiu as bordas após o movimento
                int newX = alien.getX();
                int newY = alien.getY();

                // Verifica se o alienígena estava se movendo na diagonal superior esquerda
                // Verifica se o alienígena estava se movendo na diagonal superior esquerda
                if (alien.isMovingUp() && alien.isMovingLeft()) {
                    // Se o alienígena atingiu a borda superior, muda para baixo esquerda
                    if (newY <= 0) {
                        alien.setMovingUp(false);
                        alien.setMovingDown(true);
                    }
                    // Se o alienígena atingiu a borda esquerda, muda para diagonal superior direita
                    if (newX <= Commons.BORDER_LEFT) {
                        alien.setMovingLeft(false);
                        alien.setMovingRight(true);
                    }
                }

                // Verifica se o alienígena estava se movendo na diagonal superior direita
                if (alien.isMovingUp() && alien.isMovingRight()) {
                    // Se o alienígena atingiu a borda superior, muda para baixo direita
                    if (newY <= 0) {
                        alien.setMovingUp(false);
                        alien.setMovingDown(true);
                    }
                    // Se o alienígena atingiu a borda direita, muda para diagonal superior esquerda
                    if (newX >= boardWidth - Commons.BORDER_RIGHT - Commons.ALIEN_WIDTH) {
                        alien.setMovingRight(false);
                        alien.setMovingLeft(true);
                    }
                }

                // Verifica se o alienígena estava se movendo para cima
                if (alien.isMovingUp()) {
                    // Se o alienígena atingiu a borda superior, muda para baixo
                    if (newY <= 0) {
                        alien.setMovingUp(false);
                        alien.setMovingDown(true);
                    }
                }

                // Verifica se o alienígena estava se movendo para baixo
                if (alien.isMovingDown()) {
                    // Se o alienígena atingiu a borda inferior, muda para cima
                    if (newY >= ground - Commons.ALIEN_HEIGHT) {
                        alien.setMovingDown(false);
                        alien.setMovingUp(true);
                    }
                }

                // Verifica se o alienígena estava se movendo para a esquerda
                if (alien.isMovingLeft()) {
                    // Se o alienígena atingiu a borda esquerda, muda para direita
                    if (newX <= Commons.BORDER_LEFT) {
                        alien.setMovingLeft(false);
                        alien.setMovingRight(true);
                    }
                }

                // Verifica se o alienígena estava se movendo para a direita
                if (alien.isMovingRight()) {
                    // Se o alienígena atingiu a borda direita, muda para esquerda
                    if (newX >= boardWidth - Commons.BORDER_RIGHT - Commons.ALIEN_WIDTH) {
                        alien.setMovingRight(false);
                        alien.setMovingLeft(true);
                    }
                }

                // Decrementa o contador de atraso de mudança de direção
                alien.decrementDirectionChangeDelay();
            } else {
                alien.setMovingLeft(false);
                alien.setMovingRight(false);
                alien.setMovingUp(false);
                alien.setMovingDown(false);
            }
        }
        updateOtherSprites();
    }

    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        doDrawing(g, Color.decode("#90EE90"), Color.decode("#90EE90"));
    }

    protected void updateOtherSprites() {
        Random generator = new Random();

        for (BadSprite alien : badSprites) {
            int shot = generator.nextInt(15);
            Goop goop = ((MonsterSprite) alien).getGoop();

            // Se o monstro não estiver congelado e a "gosma" estiver destruída, o monstro pode disparar outra "gosma"
            if (shot == Commons.CHANCE && alien.isVisible() && goop.isDestroyed() && !alien.isFrozen()){
                goop.setDestroyed(false);
                goop.setX(alien.getX());
                goop.setY(alien.getY());
                int randomDirectionX = generator.nextInt(3) - 1; // -1, 0, 1
                int randomDirectionY = generator.nextInt(3) - 1; // -1, 0, 1

                goop.setDirectionX(randomDirectionX);
                goop.setDirectionY(randomDirectionY);
            }
                    // Gerar direção x e y aleatórias para a goop
            int goopX = goop.getX();
            int goopY = goop.getY();
            int playerX = players.get(0).getX();
            int playerY = players.get(0).getY();

            if (players.get(0).isVisible() && !goop.isDestroyed()) {

                if (goopX >= (playerX)
                        && goopX <= (playerX + Commons.PLAYER_WIDTH)
                        && goopY >= (playerY)
                        && goopY <= (playerY + Commons.PLAYER_HEIGHT)) {

                    ImageIcon ii = new ImageIcon(explImg);
                    players.get(0).setImage(ii.getImage());
                    players.get(0).setDying(true);
                    goop.setDestroyed(true);
                }
            }

            if (!goop.isDestroyed()) {
                goop.setX(goop.getX() + goop.getDirectionX() * 3);
                goop.setY(goop.getY() + goop.getDirectionY() * 3);

                if (goop.getY() >= ground - Commons.BOMB_HEIGHT) {
                    goop.setDestroyed(true);
                }
            }
        }

        for (BadSprite alien : badSprites) {
            // Obtém as coordenadas do alien
            int alienX = alien.getX();
            int alienY = alien.getY();
            // Verifica se o alien está visível e se está em uma posição válida
            if (alien.isVisible() && alienY >= 0) {
                // Obtém as coordenadas do jogador
                int playerX = players.get(0).getX();
                int playerY = players.get(0).getY();
                // Verifica se há colisão entre o jogador e o alien
                if (playerX < alienX + Commons.ALIEN_WIDTH &&
                        playerX + Commons.PLAYER_WIDTH > alienX &&
                        playerY < alienY + Commons.ALIEN_HEIGHT &&
                        playerY + Commons.PLAYER_HEIGHT > alienY) {
                    // Se houver colisão, define o jogador como "morrendo"
                    players.get(0).setDying(true);
                    // Você pode adicionar outras ações aqui, como diminuir a vida do jogador, etc.
                }
            }
        }
    }
}