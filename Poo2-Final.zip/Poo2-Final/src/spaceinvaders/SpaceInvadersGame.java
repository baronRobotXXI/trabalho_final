package spaceinvaders;

import java.awt.EventQueue;

import spriteframework.AbstractBoard;
import spriteframework.MainFrame;
import spriteframework.image.ShipPlayerFactory;
import spriteframework.strategy.HorizontalMovementStrategy;
import spriteframework.sprite.Player;

public class SpaceInvadersGame extends MainFrame {

	public SpaceInvadersGame() {
		super("Space Invaders", 358, 350, 298);
	}

	protected AbstractBoard createBoard(int width, int height, int ground) {
		SpaceInvadersBoard board = new SpaceInvadersBoard(width, height, ground);
		Player player = board.getPlayer(0); // Supondo que haja apenas um jogador
		player.setImage(new ShipPlayerFactory());
		player.setBoard(width, height);
		player.setMovementStrategy(new HorizontalMovementStrategy());
		return board;
	}

	public static void main(String[] args) {

		EventQueue.invokeLater(() -> {

			new SpaceInvadersGame();
		});
	}

}
